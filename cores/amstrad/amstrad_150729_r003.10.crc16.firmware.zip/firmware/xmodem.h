#ifndef XMODEM_H
#define XMODEM_H

void xmodem_rx_byte(unsigned char byte);
void xmodem_poll(void);

#endif // XMODEM_H
